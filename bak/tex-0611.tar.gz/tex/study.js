/*
 * cscript study.js
 */
var print = function(msg) {
	WScript.Echo(msg);
};

var getenv = function() {
	var shell = WScript.CreateObject("WScript.Shell");
	//current user
	var env = shell.Environment("User");
	var paths = env.Item("PATH");
	var user = env.Item("NUMBER_OF_PROCESSORS");
	var user = env.Item("SYSTEMROOT");
print(user);
print(paths);
};

getenv();
